Synthetic zip-slip test fixture.
