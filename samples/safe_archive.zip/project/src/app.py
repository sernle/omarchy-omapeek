print('hello omarchy')
